
export const kSpeedHackEnabled = true;

export const kAccurateCountUpdating = false;
